package classroom;

public enum Status {
    Pending,
    Processing,
    Completed
}
