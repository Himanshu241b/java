package classroom;

public enum Priority {
    Low,
    Moderate,
    High
}
